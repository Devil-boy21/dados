package com.example.dados;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btn_lanzar;
    ImageView img;
    ImageView img2;

    TextView j1;
    TextView j2;

    final int[] dados={R.drawable.dice_1, R.drawable.dice_2, R.drawable.dice_3,
            R.drawable.dice_4, R.drawable.dice_5, R.drawable.dice_6};
    private Object TextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img=(ImageView) findViewById(R.id.imageView);
        img2=(ImageView)findViewById(R.id.imageView2);
        btn_lanzar=(Button) findViewById(R.id.btn_lanzar);
        j1=(TextView)findViewById( R.id.jugador1);
        j2=(TextView)findViewById(R.id.jugador2);
        btn_lanzar.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view==btn_lanzar){
            Log.i(null, "Lanzamos un dado"+aleatorio());
            img.setImageResource(dados[aleatorio()]);
            img2.setImageResource(dados[aleatorio()]);


        int a=aleatorio()+1;
        Log.i(null,"Lanzamos dado del jugador1"+a);
        int b= aleatorio()+1;
        Log.i(null,"Lanza el dado el jugador2"+b);
        compara(a,b);
        img.setImageResource(dados[a-1]);







        }
    }
    public int aleatorio(){
        Random random=new Random();
        int aleatorio=random.nextInt(6);
        return aleatorio;
    }
    public void compara (int a, int b){

        if (a>b) {

           j1.setText("ganste");
           j2.setText("perdiste");


        }else if (b>a){

            j2.setText("ganaste");
        }else{



        }


    }




}

